# css3-crossfade-image

An image crossfade animation made with pure CSS.

Images taken from https://unsplash.com for illustrative purposes only.
